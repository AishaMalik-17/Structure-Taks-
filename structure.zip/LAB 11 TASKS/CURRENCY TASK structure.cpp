#include<iostream>
using namespace std;
int main(){
	struct Currency{
		string TypeofCurrency;
		float amount;
	};
	Currency indollar;
	cout<<"Enter amount in Dollar: ";
	cin>>indollar.amount;
	
	float exchange;
	float dollar_rate=277.53;
	exchange=indollar.amount*dollar_rate;
	
	cout<<indollar.amount<<" $ is equal to "<<exchange<<" Rupee";
	return 0;
}
